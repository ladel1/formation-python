class Calculatrice:

    def __init__(self):
        pass

    def add(self,a,b):
        """
            Une méthode qui permet d'additionner deux nombres
        """
        return a + b
    
    def mult(seld,a,b):
        return a * b